# BGMI Tournament Bot - "Kya Tere Squad Mein Dum Hai"

## Overview

This is a comprehensive Telegram bot for managing BGMI (Battlegrounds Mobile India) tournaments. The bot handles complete tournament lifecycle from creation to winner declaration, with automated payment processing, player registration, and admin controls. It features AI-powered tournament optimization, automated time-based notifications, and a user-friendly interface for both players and administrators.

**Current Status:** ✅ Fully functional and running
**Bot Username:** @KyaTereSquadMeinDumHaiBot
**Last Updated:** July 24, 2025

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes (July 24, 2025)

✓ Fixed handler signature issues with instance method decorators
✓ Resolved asyncio event loop conflicts for proper bot startup
✓ Established successful MongoDB Atlas connection with proper indexing
✓ Implemented automated notification scheduler with time-based messaging
✓ Corrected python-telegram-bot version compatibility (v20.8)
✓ Bot is now fully operational and receiving/processing user updates
✓ Fixed non-working commands: /thismonth, /createtournamentsolo, /createtournamentsqaud
✓ Added TDM tournament creation with /createtournamenttdm command
✓ Implemented confirm/decline buttons for payment management
✓ Fixed tournament_id errors in payment confirmation handlers

## System Architecture

### Backend Architecture
- **Framework**: Python-based Telegram bot using `python-telegram-bot` library
- **Asynchronous Processing**: Built with asyncio for handling concurrent operations
- **Modular Design**: Clean separation of concerns with distinct modules for handlers, database operations, AI services, and notifications

### Database Architecture
- **Database**: MongoDB (cloud-hosted via MongoDB Atlas)
- **ODM**: Motor (async MongoDB driver for Python)
- **Collections**: 
  - Users (tournament participants)
  - Tournaments (tournament data and status)
  - Payments (payment tracking and verification)

### Authentication & Authorization
- **Admin System**: Role-based access control with decorator-based permissions
- **Channel Verification**: Mandatory channel membership verification before tournament participation
- **User Tracking**: Comprehensive user state management and session handling

## Key Components

### Core Modules
1. **Main Entry Point** (`main.py`): Application initialization and startup orchestration
2. **Handlers** (`bot/handlers.py`): Command and callback query processing with conversation flows
3. **Database Layer** (`bot/database.py`): MongoDB operations and data persistence
4. **AI Service** (`bot/ai_service.py`): OpenAI GPT-4 integration for tournament suggestions and analytics
5. **Notification System** (`bot/notifications.py`): Automated time-based messaging and tournament reminders
6. **Configuration** (`bot/config.py`): Environment-based configuration management

### User Interface Components
- **Keyboards** (`bot/keyboards.py`): Inline keyboard layouts for user interactions
- **Messages** (`bot/messages.py`): Template-based messaging system with randomized content
- **Decorators** (`bot/decorators.py`): Access control and permission enforcement

## Data Flow

### Tournament Registration Flow
1. User starts bot → Channel membership verification
2. User selects tournament → Payment instruction display
3. Payment completion → Admin verification
4. Confirmation → Tournament participation activated

### Admin Tournament Management Flow
1. Admin creates tournament → Database storage
2. Tournament announcement → User notifications
3. Registration period → Payment tracking
4. Tournament execution → Result processing

### Notification Flow
1. Scheduler triggers time-based notifications
2. User segmentation based on activity and preferences
3. Message customization and delivery
4. Engagement tracking and analytics

## External Dependencies

### Third-Party Services
- **Telegram Bot API**: Core messaging and user interaction platform
- **OpenAI API**: AI-powered tournament analysis and suggestions (GPT-4)
- **MongoDB Atlas**: Cloud database hosting and management
- **UPI Payment System**: Payment processing integration

### Python Libraries
- `python-telegram-bot`: Telegram bot framework
- `motor`: Async MongoDB driver
- `aiohttp`: Async HTTP client for AI API calls
- `asyncio`: Asynchronous programming support

## Deployment Strategy

### Environment Configuration
- **Environment Variables**: Secure credential management via environment variables
- **Configuration Class**: Centralized configuration with fallback defaults
- **Multi-Environment Support**: Separate configurations for development and production

### Runtime Requirements
- **Python 3.8+**: Async/await syntax support
- **MongoDB Connection**: Persistent database connectivity
- **External API Access**: Internet connectivity for Telegram and OpenAI APIs
- **Webhook Support**: Optional webhook deployment for production scaling

### Monitoring & Logging
- **Structured Logging**: Comprehensive logging with different severity levels
- **Error Handling**: Graceful error handling with user-friendly error messages
- **Performance Tracking**: Database operation monitoring and optimization

### Scalability Considerations
- **Async Architecture**: Non-blocking operations for handling multiple users
- **Database Indexing**: Optimized queries with proper indexing strategy
- **Memory Management**: Efficient state management for conversation flows
- **Rate Limiting**: Built-in Telegram API rate limit handling